# AI 引き継ぎ

## 基準
- ゲーム：ともしびアイランド（ブラウザー3D冒険RPG / PWA）
- GitHub：https://github.com/mga572que-eng/kazetomo
- 公開URL：https://mga572que-eng.github.io/kazetomo/
- 基準main：d47f2db4b2eeca8fad0ae1a99e589fd3daa35300（2026-10-02、Claude追加7機能まで公開確認済み）
- 公開版：20261002104321。今回のローカル版：20261002132328（未公開）
- 記録日：2026-10-02 JST
- 担当：固定しない（Claude / Codex / Gemini）。今回の記録：Codex

## 構成と壊しやすい箇所
ビルド不要のHTMLと通常スクリプト。index.htmlの順序：pwa → music → art → data → art_mon → art_face → world → game → settings → life → shrines → base → ch4 → jobs → quests → deco → ux → onboard → unstuck → names → balance → battle3d → talk → town → mobs → monplus → gemini-talk → jobfield → lighthouses → townlife → interiors → newtowns → recipes → payoff → titles2 → weather → townbuildings → fieldexplore → fieldtravel → adventurelife。
world.jsが描画・地形、game.jsが進行・戦闘・セーブとwindow.KZ/HOOK。後続モジュールはKZ/HOOKへ追加する。data.jsが共通データ、ch4.jsが第4章、jobs/quests/base/life/shrinesが拡張、ux/onboard/unstuck/settingsが操作・救出・設定。
追加モジュール：names（技の表示名）、balance（そうび袋・防具の種類・店・売却、K.bal）、battle3d（立体バトル、設定で平面に戻せる）、talk / gemini-talk（仲間会話）、town（酒場・訳あり家・探索）、mobs（町の住人）、monplus（モンスター装備・覚醒・連携）。
セーブ：kazetomo-rpg-3、追加スロットkazetomo-rpg-3-sN、旧kazetomo-rpg-1。設定：kazetomo-opt。IDと進行フラグを勝手に変更しない。
追加のセーブ値：bag、armTier、talkSeen、talkIdx、town、flags.tw_*、monEq、monAwake。旧セーブでは無くても動く（HOOK.loadで補う）。
PWA版番号はindex/pwa/sw/versionで同期する。

## 以前の検証履歴（2026-10-01時点。現在の状態は末尾の2026-10-02更新を参照）
| 区分 | 内容 |
|---|---|
| 公開済み（main・Pages） | PR #3〜#11 と、直接アップロード 301ca07〜7c699d9（Gemini成果の適用・小修正）。自動検査（Game checks・build・deploy）は、すべて success |
| 当時の保存済み・未統合 | なし（2026-10-01 20:55 時点。今回の作業とは別） |
| ローカルの実ゲーム検査 | Codex：装備・覚醒・在庫・セーブ／ロードなど14項目。Claude：メニュー7項目、仲間会話25回（重複なし）、戦闘、新しいセーブ値の保存。どちらもエラー0 |
| 844×390 画面 | ブラウザの模擬画面で確認済み（そうび・モンスター・戦闘） |
| **未確認** | **iPhone 実機**（立体バトルの重さ・操作・PWA）、**全章の通しプレイ**、旧セーブでの長時間の継続 |

## 継続する運用方針と未確認事項
- 計画と優先順位：docs/plan/NEXT.md。他のAIへの依頼文：docs/plan/PROMPTS.md。
- 優先順位（開発者決定）：
  1. 作業記録の更新・改行のLF統一（専用PR）・PR運用
  2. 新しいモジュールの監査と、既存設定との食い違いの修正
  3. iPhoneでの10分テストと、その結果にもとづく改善
  4. 追加要素（落下ダメージは仕様を先に決める・職業支援・物語改稿）
- 運用：mainへ直接アップロードしない。作業ブランチ → PR → 統合。Geminiへの依頼は1件ずつ、対象コミットと必要なソースだけを渡す。成果物はClaudeかCodexが確認・適用・検査してからPRにする。
- 物語の新しい過去・年齢・家族関係（docs/design/story.md・docs/lore/foreshadow.md）は未承認の提案。本編に入れない。
- 文の方針：「難しい漢字はひらがな」を維持。意味が取りにくい文を個別に直す。固有名詞は本編の表記に合わせる。
- Claude環境の旧 `deploy.sh`（リポジトリ外）は使用禁止（リポジトリを丸ごと上書きする方式のため）。

## 次回終了時に更新
担当 / 開始コミット / 終了コミット / 変更ファイル / 実施した検証と結果（保存済み／公開済み／未確認を分ける） / 未解決 / 次の一手。

## PCに依存しない設定の追加
.devcontainer（Node 22）、.nvmrc、GitHub検査と手動バックアップワークフロー、CLOUD_DEVELOPMENT.mdを追加。リモート反映・main統合とGame checks成功を確認済み。Codespacesの初回起動は未実施。保存はGitHubへのcommit/pushを完了条件とする。セーブはブラウザー単位で自動同期されない。

## リモート最終確認（2026-10-01）
- PR #1統合後、設定ファイルを所定の場所へ配置。ゲーム実行ファイルは初回基準から差分なし。
- 確認コミット：7ddca17bbfe2d9bcdae2f4fedb18cb65b928767f（この文書更新直前）。
- GitHub Game checksと取得したmainの構文・参照・PWA検査は成功。mainバックアップのbundle復元も確認。
- クラウドバックアップ初回はupload-artifact v7の相対パス制限で失敗。runner.tempへコピーする修正を反映し、再実行：https://github.com/mga572que-eng/kazetomo/actions/runs/36805603525
- SETUP_REPORT.mdの初期リモート未反映記録は過去の状態。この節を最新の進捗として扱う。

## Gemini 4件の適用（2026-10-01）
- 基準main: 301ca07。work/gemini-fourで実装。main 0d8f77fでゲーム12ファイルの一致と公開を確認、b0fd71dで設計・物語文書3ファイルも保存確認。
- gemini-talk.js: AI Studioの追加会話65件と口調45種を登録。コオリドリ1種は既存の会話を補完。talk.jsの選択機構にregister APIを足し、既読キーと隊列・個体の条件を維持する。
- mobs.js: 今回のGemini全文の住人86人を採用。既存の生成町の座標に合わせ、障害物や建物を避けて7町に配置。以前の48人版を更新した。
- town.js: 酒場4店、訳あり家6軒、探索29か所。G.townとG.flags.tw_*で独立して保存。既存本編フラグは変更しない。
- monplus.js: 装備9種、覚醒、連携6種。本体にモンスターのcalcフックを接続し、パネルへの入口と連携UID、MP二重消費を修正。対応済み/設計のみの効果はdocs/design/monsters.md冒頭に明記。
- docs/lore/foreshadow.md、docs/design/monsters.md、docs/design/story.mdはGemini成果物の全文。物語の新しい過去・年齢は提案扱いで、本編には実装していない。
- 追加の画面文言は難しい漢字をひらがなにした。表示名以外のID・既存セーブキー・キャラの種族IDは維持。
- 検証: 構文/参照/PWA、実ゲームで4モジュール、候補会話・同席除外、86人の安全配置、4店、探索の一度だけ取得、装備/覚醒のステータス、連携UID、実save/load保持。844x390でモンスター画面も確認。実端末と全シナリオ通しプレイは未検証。

## Gemini共同レビューによる小修正（2026-10-01）
- 基準main b0fd71d、作業ブランチwork/gemini-polish。装備/バトル・UI/セーブ・QAの観点をGoogle AI Studioへ依頼し、Codexがソースと照合して修正。
- monplus.js: 装備変更時のHP0を維持、HP/MP比率と上限を維持、未知装備IDの参照と在庫返却をガード。未知IDをロード時に削除しない。覚醒の実行側にもなつき100/覚醒済みガード、ソラ同席時のみ発言、能力説明を実効果へ合わせ、保存失敗を通知。
- 設計の変更は行わず、牧場からの覚醒を維持。Geminiの未知ID一括削除案と隊列必須案は採用していない。
- ゲーム版番号20261001184146。ローカル保存とGitHub保存/公開は分けて確認する。

## 2026-10-02：町の外観・残り7基の灯台（Codex）

作業ブランチ work/towns-lighthouses、基準main d47f2db。以前のClaude追加7機能はmain d47f2dbに反映済み。今回の変更はローカル保存、GitHubへ未送信・未公開。

townbuildings.jsをweather.jsの後に追加。10町の既存住宅の外壁・屋根だけを変更し、入口・建物ID・住人を保持。lighthouses.jsは島5基・海3基を任意回廊として提供。海の点火はG.lh[i]。旧G.lhDun[0]を維持し、海の記録はsea0〜sea2。G.lhDunExitに帰還先を追加する。ブロック設置は回廊内で禁止、旧プレイヤーブロックは消さない。

各灯台は共通の飛び石・収集と固有の操作順パズル。元設計の物理仕掛けの全量実装ではない。現行仕様・検証範囲はdocs/design/towns-lighthouses-implementation.md。回廊は地域ごとに使い回し、描画上限に収める。Node回帰検査はnode tests/towns-lighthouses.mjs。iPhone実機と手操作による全灯台の通し攻略は未検証。

## 2026-10-02 地形・探索・乗り物（ローカル保存、未公開）
- fieldexplore.js：4地域に各3か所、計12か所。発見報酬は一度だけ。たんさく帳・地図の発見マーク・短い石の道。
- fieldtravel.js：地域1の川と橋、地域0の階段付き崖、4つのみちのえき、既存海岸近くの追加船着き場2か所。馬・現在隊列の生きている仲間モンスター・手こぎ舟。
- セーブ追加値 G.fieldExplore と G.travel。旧セーブではHOOK.loadで補完。乗っている状態は保存せず、舟での保存は乾いた安全な岸へ。章進行の船移動とは独立。
- game.jsの既存saveコメントに巻き込まれていたG.placed/G.lit/G.guardの記録を復旧。実ブラウザーで設置ブロック・灯台点火・番人状態を保存/再読込確認。
- World.setTerrainPatchesは限定された空き地の川・崖用。通常地形の生成式、既存ID、章フラグは維持。乗り物はHOOK.travelSpeed/travelSurface/travelStamina/savePositionを使用。
- 構文・参照・PWA、Nodeの町/灯台・乗り物検査、ローカルChromeの発見・保存・橋/舟の実移動を確認。iPhone実機と全章通しプレイは未確認。詳しくはdocs/design/field-exploration-and-travel.md。

## 2026-10-02 遊びやすさ・旅支度・転職像（未公開）
- game.jsの走るポーズ用boolean runがイベント実行関数runを隠して敵接触時にTypeErrorになっていた。runningへ変更。Chromeで接触→戦闘→攻撃→勝利→フィールド復帰を確認。
- 住人は地面基準の足場を使う。townlifeでは会話相手を停止/対面、行き先の安全と住人間隔を確認し、小さなハヤテの広場を別設定にした。0,0へ出る不正な代替位置を防止。GのNPC IDは維持。
- 家の壁の幅5→7ブロック、屋根7→9ブロック。部屋の壁11→17、家具間隔1.6倍、入口・出口を変更。描画ブロック上限を14000→24000に拡大し切り捨てを防いだ。
- がんばりは固定UI。残り/最大と20点を1こに換算した容量を表示。最大容量に応じて緑バーの長さが増える。一人称でも表示。DOM再構築は整数表示が変化した時だけ。
- adventurelife.js：新しい防寒服（DATA.armorの末尾）、ツムギの既存会話に現在の旅支度を追加、地域1の山道条件、空き地の尾根、朝市、家畜の世話係。防寒服はソラに装備して雪原へ。山道は容量180またはイワノコ/イワゴロン、北の高所は同種に乗る必要がある。困った時は「たびの したく」。
- 魚は12→24種。以後の釣果だけG.fishStockに記録して朝5〜10時にシオミ/ミナト/アワで売る。旧図鑑記録から売却在庫を捏造しない。既存の料理用さかな取得は維持。
- G.adventure（防寒服受取/世話記録）とG.fishStockは欠けた旧セーブを補完する。家畜の世話は600プレイ秒ごとに1回。既存の章フラグは変更していない。
- 服は防具の種類と番号による色・肩当て・防寒ショール、武器は金属色が変わる。全装備専用の新規形状を作ったものではない。描画は既存humanを使用。ポーズキャッシュに防具と武器の番号を含める。
- jobs.jsは調べる点と光だけだった転職地点に実物の像/台座を追加、近場の安全な場所へ調整、名前札/地図マーク/対象距離を拡大。第1章クリアの解放条件・転職費用・スキル処理は維持。
- 詳細と確認の限界はdocs/design/playability-and-regional-travel.md。iPhone実機と全章通しは未確認。
