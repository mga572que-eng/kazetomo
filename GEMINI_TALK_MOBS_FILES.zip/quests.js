// ともしびアイランド — 町と 頼まれごと：隣町シオミ・灯台の 鍵クエスト・各町の サイドクエスト
'use strict';
(() => {
  const K = window.KZ; if (!K) return; const H = K.HOOK, B = World.Blocks;
  const G = () => K.G, who = K.who, nm = K.nm;

  // ================= 隣町「潮見の町 シオミ」（風灯の島） =================
  const R0 = K.REG[0]; World.setRegion(0);
  const shiomi = (() => { let best = null;
    const far = (x, z) => Math.hypot(x - R0.town.x, z - R0.town.z) > 85 && !R0.beacons.some(b => Math.hypot(b.x - x, b.z - z) < 42) && !(R0.shrine && Math.hypot(R0.shrine.x - x, R0.shrine.z - z) < 40)
      && !(DATA.shrines || []).some(s => s.r === 0 && s.pos && Math.hypot(s.pos.x - x, s.pos.z - z) < 36) && !(K.baseSite && Math.hypot(K.baseSite.x - x, K.baseSite.z - z) < 36) && Math.hypot(x - R0.pier.x, z - R0.pier.z) > 30;
    for (let a = 0; a < 72; a++) for (let d = 90; d < 190; d += 8) { const an = a / 72 * Math.PI * 2, x = Math.round(Math.cos(an) * d), z = Math.round(Math.sin(an) * d); const h = K.hAt(x, z); if (h < 2.5 || h > 16 || !far(x, z)) continue;
      let mn = 1e9, mx = -1e9; for (let i = -14; i <= 14; i += 4) for (let j = -14; j <= 14; j += 4) { const hh = K.hAt(x + i, z + j); mn = Math.min(mn, hh); mx = Math.max(mx, hh); } if (mn < 1.8) continue;
      const sc = mx - mn; if (!best || sc < best.sc) best = { x, z, sc }; }
    return best || { x: -120, z: 60, sc: 0 }; })();
  const SX = shiomi.x, SZ = shiomi.z; shiomi.name = '潮見の町 シオミ';
  R0.trees.forEach(t => { if (Math.hypot(t.x - SX, t.z - SZ) < 22) { t.state = 'gone'; t.t = -1e9; } }); R0.rocks.forEach(t => { if (Math.hypot(t.x - SX, t.z - SZ) < 20) { t.state = 'gone'; t.t = -1e9; } });
  R0.bushes = R0.bushes.filter(t => Math.hypot(t.x - SX, t.z - SZ) >= 18);
  const hs = [{ id: 'nami', x: SX, z: SZ - 11 }, { id: 'sinn', x: SX - 12, z: SZ - 2 }, { id: 'sitem', x: SX + 12, z: SZ - 3 }, { id: 'ryou', x: SX + 9, z: SZ + 10 }, { id: 'ruin1', x: SX - 10, z: SZ + 11 }, { id: 'ruin2', x: SX + 1, z: SZ + 15 }];
  hs.forEach((h, i) => { h.face = [SX, SZ]; K.buildHouse(h, [{ wall: 4, roof: 3, corner: 5 }, { wall: 4, roof: 8 }, { wall: 6, roof: 3 }, { wall: 0, roof: 3 }, { wall: 6, roof: 3 }, { wall: 4, roof: 3 }][i]); });
  // 焼けた 家（屋根と 壁を くずす）
  for (const h of hs.filter(h => h.id.startsWith('ruin'))) { const cx = Math.round(h.x), cz = Math.round(h.z); let fy = 1e9; const cells = [];
    B.each(0, (k) => { const [x, y, z] = k.split(',').map(Number); if (Math.abs(x - cx) <= 3 && Math.abs(z - cz) <= 3) cells.push([x, y, z]); });
    for (const [x, y, z] of cells) if (Math.abs(x - cx) <= 1 && Math.abs(z - cz) <= 1) fy = Math.min(fy, y + 1);
    for (const [x, y, z] of cells) { const hsh = (x * 7 + z * 13 + y * 5) & 7; if (y >= fy + 3 || (y === fy + 2 && hsh < 5) || (y === fy + 1 && hsh < 2)) B.rm(x, y, z, 0); else if (y >= fy && hsh === 7) B.set(x, y, z, 5, true, 0); } }
  for (const [x, z] of [[SX - 5, SZ + 4], [SX + 5, SZ + 4], [SX - 5, SZ - 5], [SX + 5, SZ - 5]]) { const b = Math.floor(K.hAt(x + .5, z + .5)); B.set(x, b, z, 5, true, 0); B.set(x, b + 1, z, 5, true, 0); B.set(x, b + 2, z, 2, true, 0); }
  // 井戸
  { const b = Math.floor(K.hAt(SX + .5, SZ + .5)); for (let dx = -1; dx <= 1; dx++) for (let dz = -1; dz <= 1; dz++) if (dx || dz) B.set(SX + dx, b, SZ + dz, 1, true, 0); shiomi.well = { x: SX + .5, z: SZ + .5 }; }
  const hp = id => hs.find(h => h.id === id).npc;
  const addNpc = n => { n.yaw = n.yaw || 0; n.baseYaw = n.yaw; K.NPCS.push(n); return n; };
  addNpc({ id: 'nami', r: 0, x: hp('nami').x, z: hp('nami').z, yaw: hs[0].yaw, nm: '町長ナミ' });
  addNpc({ id: 'inn', r: 0, x: hp('sinn').x, z: hp('sinn').z, yaw: hs[1].yaw, nm: '宿屋「しおかぜ亭」' });
  addNpc({ id: 'item', r: 0, x: hp('sitem').x, z: hp('sitem').z, yaw: hs[2].yaw, nm: 'シオミの 道具屋' });
  addNpc({ id: 'ryou', r: 0, x: hp('ryou').x, z: hp('ryou').z, yaw: hs[3].yaw, nm: '漁師リョウ' });
  addNpc({ id: 'chibi', r: 0, x: SX + 3, z: SZ + 3, nm: 'チビ', show: () => !!(q('k1b').s === 'd' || !q('k1b').s) });
  K.shiomi = shiomi;
  // 他の 町の 住人（サイドクエスト用）
  const T1 = K.REG[1].town, T2 = K.REG[2].town, T3 = K.REG[3].town;
  addNpc({ id: 'ryou', r: 1, x: T1.x + 9, z: T1.z + 12, nm: '港の 漁師ドン' });
  addNpc({ id: 'chibi', r: 1, x: T1.x - 7, z: T1.z + 6, nm: '港の 子 ルル' });
  addNpc({ id: 'nami', r: 2, x: T2.x - 8, z: T2.z + 8, nm: '雲の 織り手 ワタ' });
  World.setRegion(0);

  // ================= クエスト 定義 =================
  const LV = () => DATA.guardLv[Math.min(G().order, 4)];
  const spots = {
    forest: (() => { let p = null; for (let a = 0; a < 36 && !p; a++) { const an = a / 36 * 6.283, x = SX + Math.cos(an) * 34, z = SZ + Math.sin(an) * 34; if (K.hAt(x, z) > 2.5 && World.biomeAt(x, z) === 'forest') p = { x, z }; } return p || { x: SX + 30, z: SZ - 18 }; })(),
    dock: { x: SX + 16, z: SZ + 14 },
    hill: (() => { let p = null, best = -1; for (let k = 0; k < 400; k++) { const x = R0.town.x + (Math.sin(k * 12.9898) * 43758.5453 % 1) * 120, z = R0.town.z + (Math.sin(k * 78.233) * 12543.21 % 1) * 120; const h = K.hAt(x, z); if (h > best && h < 26 && Math.hypot(x, z) > 30) { best = h; p = { x, z }; } } return p; })(),
    desert: { x: 105, z: 40, r: 1 },
  };
  DATA.reqs = [
    // ---- 第1章：灯台の 鍵 ----
    { id: 'k0', key: 0, r: 0, giver: 'gen', town: '風見の村', title: '灯台の 鍵', steps: [{ t: 'shards', n: 3, text: '灯台の まわりの 野原で「灯の欠片」を 3つ 集める' }],
      offer: [who('gen', 'neutral', '灯台の 扉は、灯の欠片を はめないと ひらかねえ。 カイトが そう 作った。 ……あいつらしい 用心だ。'), who('gen', 'neutral', '欠片は 北の 灯台の まわりの 野原で 光ってる。 3つ そろったら、そのまま 扉に はめこめ。 それが 鍵だ。')],
      done: [who('gen', 'grin', '……よし。 これで 鍵が 打てる。'), '「灯台の 鍵」を 手に入れた！ 灯台で 番人が まっている。'], reward: { gold: 100 } },
    { id: 'k1a', key: 1, r: 0, giver: 'nami', town: 'シオミ', title: 'こわれた 井戸', steps: [{ t: 'collect', item: 'ishi', n: 5, text: '石を 5こ 集めて 町長ナミへ（岩を 掘る）' }],
      offer: [nm('町長ナミ', 'ようこそ、潮見の町シオミへ……と 言いたいけれど、見ての とおりよ。 半年前、かげものに 町の 半分を 焼かれたの。'), nm('町長ナミ', '井戸も こわされて、水が くめない。 石を 5つ あつめて もらえないかしら。')],
      done: [nm('町長ナミ', 'ありがとう！ これで 井戸が なおせるわ。'), who('sora', 'smile', 'よかった。 ……ほかにも こまってる 顔、してますね。')], reward: { gold: 150, give: { mi: 3 } } },
    { id: 'k1b', key: 1, r: 0, giver: 'nami', town: 'シオミ', title: 'まいごの チビ', req: 'k1a', steps: [{ t: 'visit', spot: 'forest', text: '町の 外の 森で 迷子の チビを さがす', fight: ['watapoko', 'iwanoko'] }],
      offer: [nm('町長ナミ', 'たいへん！ チビが 森へ 行ったきり 帰ってこないの。 「リクにいちゃんを さがす」って……。'), who('sora', 'determined', 'ぼくたちが さがしてくる！')],
      visit: ['しげみの 奥で、チビが かげものに かこまれている！'],
      visitDone: [nm('チビ', 'うわーん！ ……おにいちゃん、ありがと。 リクにいちゃん、町を 出ていっちゃったの。 おとなが「出ていけ」って 言ったから。'), who('mio', 'worried', '……出ていけ？'), 'チビを 町長ナミの ところへ つれて 帰ろう。'],
      done: [nm('町長ナミ', 'チビ！ よかった……本当に ありがとう。'), nm('町長ナミ', 'リクは 海から 流れついた 子よ。 半年前 町が 焼けた とき、みんな「よそ者が かげを 連れてきた」って あの子を 責めた。'),
        nm('町長ナミ', '……わたしは 町長なのに、止めなかった。 灯台で あの子に 会ったら、どうか 力に なってあげて。'), '「灯台の 鍵」を たくされた！ 灯台で 番人が まっている。'], reward: { gold: 200, give: { pan: 2 } } },
    { id: 'k2', key: 2, r: 0, giver: 'ryou', town: 'シオミ', title: '港を まもれ', steps: [{ t: 'waves', spot: 'dock', n: 3, text: 'シオミの 港で おしよせる かげものを 3回 しずめる' }],
      offer: [nm('漁師リョウ', '……リク。 もどって きたのか。'), who('riku', 'smirk', '用が あるのは こいつらだ。 おれじゃねえ。'),
        nm('漁師リョウ', '……そうか。 たのみが ある。 夜ごとに 港へ かげものの 群れが 押しよせて、船が 出せねえ。 桟橋で 3回、追いはらって くれ！')],
      done: [nm('漁師リョウ', 'やるじゃねえか！ これで 船が 出せる。'), nm('漁師リョウ', '……リク。 あの日、「出ていけ」って 石を 投げたのは おれだ。 家を 焼かれて、だれかの せいに したかった。 ……すまなかった。'),
        who('riku', 'sad', '…………。 ……干し魚。 あとで 持ってこい。 それで ちゃらだ。'), who('sora', 'smile', '（リク、ちょっと 笑ってる……）'),
        nm('漁師リョウ', 'ああ、山ほど な。 ……これは 灯台の 鍵だ。 岩山の 灯台は 地ひびきの 番人が 守ってる。 気をつけな。')], reward: { gold: 300, give: { shizuku: 2 } } },
    { id: 'k3', key: 3, r: 0, giver: 'nagi', town: '風見の村', title: '月光花の 灯', steps: [{ t: 'visit', spot: 'hill', night: true, text: '夜に 島の 高い 丘で「月光花」を つむ' }],
      offer: [who('nagi', 'smile', 'ねえ {name}。 夜の 灯台の 火皿はね、月光花の 花粉で しか ひらかないの。'), who('nagi', 'determined', '島で いちばん 高い 丘に、夜だけ 咲くのよ。 つんで きてくれる？')],
      visit: ['月あかりの 下、青白く 光る 花が 咲いている……。'], visitDone: ['「月光花」を つんだ！ ナギに とどけよう。'],
      done: [who('nagi', 'joy', 'きれい……！ これで 夜の 灯台が ひらくわ。'), '夜の 灯台の 鍵を 手に入れた！（夜に 番人が あらわれる）'], reward: { gold: 350, give: { shizuku: 2 } } },
    { id: 'k4', key: 4, r: 0, giver: 'ryou', town: 'シオミ', title: '崖の 灯台への 道', steps: [{ t: 'collect', item: 'ha', n: 5, text: '葉っぱ 5こ（木を 切る）' }, { t: 'collect', item: 'shizuku', n: 1, text: '夜露の しずく 1こ' }],
      offer: [nm('漁師リョウ', '最後の 灯台は 崖の 先の 浮き足場だ。 おれの 網を 直した 帆布で、足場への 綱を 張ってやる。'), nm('漁師リョウ', '葉っぱ 5つと 夜露の しずく 1つ。 たのんだぜ。')],
      done: [nm('漁師リョウ', 'よし、綱を 張った！ 風布が あれば 滑空で、なければ ブロックの 橋で わたれ。'), '崖の 灯台の 鍵を 手に入れた！'], reward: { gold: 400, give: { ganbari: 2 } } },
    // ---- サイドクエスト ----
    { id: 's_chibi', r: 0, giver: 'chibi', town: 'シオミ', title: 'チビの いきもの図鑑', req: 'k1b', steps: [{ t: 'dex', n: 6, text: 'いきもの図鑑を 6種 うめて チビに 見せる' }],
      offer: [nm('チビ', 'ねえねえ、いきもの図鑑 もってるの？ 6しゅるい うまったら 見せて！')], done: [nm('チビ', 'すごーい！ おれいに これ あげる！')], reward: { give: { nakayoshi: 2 } } },
    { id: 's_ryou', r: 0, giver: 'ryou', town: 'シオミ', title: '大漁 祈願', req: 'k4', steps: [{ t: 'collect', item: 'sakana', n: 3, text: '魚を 3びき（釣りざおで 釣る）' }],
      offer: [nm('漁師リョウ', 'ひさしぶりに 魚が 食いてえ。 3びき 釣ってきて くれねえか？')], done: [nm('漁師リョウ', 'うまそうだ！ ほら、礼だ。')], reward: { gold: 600 } },
    { id: 's_don', r: 1, giver: 'ryou', town: '港町ミナト', title: '倉庫の かげもの', steps: [{ t: 'hunt', region: 1, n: 6, text: '霧の大陸で かげものを 6回 たおす' }],
      offer: [nm('港の 漁師ドン', '倉庫の まわりに かげものが 住みついちまった。 大陸で 6回 追いはらって くれ。')], done: [nm('港の 漁師ドン', 'たすかったぜ！')], reward: { gold: 900, give: { shizuku: 2 } } },
    { id: 's_ruru', r: 1, giver: 'chibi', town: '港町ミナト', title: '砂漠の 星砂', steps: [{ t: 'visit', spot: 'desert', text: '東の 砂漠で 星砂を ひろう', fight: ['sunawani', 'hibana'] }],
      offer: [nm('港の 子 ルル', '砂漠にはね、星の かけらが まざった 砂が あるんだって。 ほしいなあ……。')], visit: ['砂の 中で、ちいさな 星が きらめいている！ ……かげものが 気づいた！'], visitDone: ['「星砂」を ひろった！ ルルに とどけよう。'],
      done: [nm('港の 子 ルル', 'わあ、きらきら！ ありがとう！ これ、宝物の はんぶん あげる！')], reward: { give: { hoshikake: 2 } } },
    { id: 's_wata', r: 2, giver: 'nami', town: '雲の里ククル', title: '雲わたの 布', steps: [{ t: 'collect', item: 'kumowata', n: 5, text: '雲わた 5こ（空の いきもの・雲の 茂み）' }],
      offer: [nm('雲の 織り手 ワタ', '里の みんなの 冬の 布団が 足りないの。 雲わたを 5つ あつめて くれない？')], done: [nm('雲の 織り手 ワタ', 'ふかふかの 布団が できるわ！ お礼に 雲の ブロックを どうぞ。')], reward: { gold: 1500, blocks: { 11: 20 } } },
  ];
  // ================= 第2章：オアシスの村 サラム（霧の大陸・砂漠） =================
  const mkTown = (r, center, list, styles) => { World.setRegion(r); const R = K.REG[r];
    R.trees.forEach(t => { if (Math.hypot(t.x - center.x, t.z - center.z) < 20) { t.state = 'gone'; t.t = -1e9; } }); R.rocks.forEach(t => { if (Math.hypot(t.x - center.x, t.z - center.z) < 18) { t.state = 'gone'; t.t = -1e9; } }); R.bushes = R.bushes.filter(t => Math.hypot(t.x - center.x, t.z - center.z) >= 16);
    list.forEach((h, i) => { h.face = [center.x, center.z]; const rb = B.set; K.buildHouse(h, styles[i]); }); World.setRegion(0); };
  const oasis = (() => { World.setRegion(1); let best = null; for (let x = 50; x <= 200; x += 6) for (let z = -120; z <= 150; z += 6) { if (World.biomeAt(x, z) !== 'desert') continue; if (Math.hypot(x - World.RUINS1[0], z - World.RUINS1[1]) < 75 || Math.hypot(x - T1.x, z - T1.z) < 90) continue;
      let mn = 1e9, mx = -1e9; for (let i = -12; i <= 12; i += 4) for (let j = -12; j <= 12; j += 4) { const hh = K.hAt(x + i, z + j); mn = Math.min(mn, hh); mx = Math.max(mx, hh); } if (mn < 3) continue; const sc = mx - mn; if (!best || sc < best.sc) best = { x, z, sc }; } World.setRegion(0); return best || { x: 120, z: 80 }; })();
  const oh = [{ id: 'oelder', x: oasis.x, z: oasis.z - 10 }, { id: 'ourana', x: oasis.x - 11, z: oasis.z + 2 }, { id: 'oinn', x: oasis.x + 11, z: oasis.z + 3 }];
  mkTown(1, oasis, oh, [{ wall: 4, roof: 9, corner: 5 }, { wall: 9, roof: 3 }, { wall: 4, roof: 9 }]);
  { World.setRegion(1); const b = Math.floor(K.hAt(oasis.x + .5, oasis.z + 4.5)); for (let dx = -2; dx <= 2; dx++) for (let dz = 2; dz <= 6; dz++) { if (Math.abs(dx) === 2 || dz === 2 || dz === 6) B.set(oasis.x + dx, b, oasis.z + dz, 1, true, 1); } World.setRegion(0); }
  addNpc({ id: 'ushio', r: 1, x: oh[0].npc.x, z: oh[0].npc.z, yaw: oh[0].yaw, nm: '村長ハッサン' });
  addNpc({ id: 'nami', r: 1, x: oh[1].npc.x, z: oh[1].npc.z, yaw: oh[1].yaw, nm: '星占いの ウララ' });
  addNpc({ id: 'oinn', r: 1, x: oh[2].npc.x, z: oh[2].npc.z, yaw: oh[2].yaw, nm: 'オアシスの 宿' }); H.talks.oinn = async () => K.talkInn();
  spots.dune = { x: oasis.x + 26, z: oasis.z - 22 };
  // ================= 第3章：風車の集落 ハヤテ（天空の浮島・西の小島） =================
  const I8 = World.ISL2[8]; const hayate = { x: I8.x, z: I8.z };
  const hh3 = [{ id: 'hmill', x: hayate.x + 4, z: hayate.z - 3 }, { id: 'hhome', x: hayate.x - 5, z: hayate.z + 3 }];
  mkTown(2, hayate, hh3, [{ wall: 0, roof: 11, corner: 5 }, { wall: 4, roof: 11 }]);
  { World.setRegion(2); const cx = Math.round(hayate.x + 4), cz = Math.round(hayate.z - 3); const top = Math.floor(K.hAt(cx + .5, cz + .5)) + 8; for (let y = top; y < top + 5; y++) B.set(cx, y, cz, 5, true, 2); for (let k = -3; k <= 3; k++) { B.set(cx + k, top + 4, cz + 3, 0, true, 2); B.set(cx, top + 4 + k, cz + 3, 0, true, 2); } spots.mill = { x: cx + .5, z: cz + .5 }; World.setRegion(0); }
  addNpc({ id: 'ryou', r: 2, x: hh3[0].npc.x, z: hh3[0].npc.z, yaw: hh3[0].yaw, nm: '風車守り カザミ' });
  addNpc({ id: 'chibi', r: 2, x: hayate.x - 2, z: hayate.z + 7, nm: 'ハヤテの 子 ソラネ' });
  (K.extraAreas = K.extraAreas || []).push({ rg: 1, id: 'oasis', x: oasis.x, z: oasis.z, r: 24, n: 'オアシスの村 サラム', s: '霧の大陸' }, { rg: 2, id: 'hayate', x: hayate.x, z: hayate.z, r: 16, n: '風車の集落 ハヤテ', s: '天空の浮島' });
  K.oasis = oasis; K.hayate = hayate;
  const F = () => G().flags;
  DATA.reqs.push(
    { id: 'c2a', gate: 2, r: 1, giver: 'ushio', town: 'サラム', title: '埋まった 井戸', when: () => F().c2rumor, steps: [{ t: 'collect', item: 'ishi', n: 6, text: '石を 6こ（井戸の 石組みに）' }, { t: 'hunt', region: 1, n: 3, text: '村の まわりの かげものを 3回 しずめる' }],
      offer: [nm('村長ハッサン', '旅の 方か。 すまんが 宿も 満足に 出せん。 砂嵐で 井戸が 埋まり、かげものが 水場を 荒らしておる。'), nm('村長ハッサン', '石を 6つ、それと 村の まわりの かげものを 3度 追いはらって くれんか。'),
        who('sora', 'determined', 'まかせて！ ……ところで、紺色の 髪の 女の子を 見ませんでしたか？'), nm('村長ハッサン', '……知っておるよ。 じゃが ただで 話すほど、砂漠の 水は 安くない。 井戸が 直ったら、話して やろう。'),
        who('sora', 'worried', '（……けっこう ちゃっかり してる）')],
      done: [nm('村長ハッサン', '水が 出た！ 村の 恩人じゃ。'), nm('村長ハッサン', 'あの 子の ことは ウララに 聞きなされ。 ずっと 気に かけておったよ。')], reward: { gold: 500, give: { shizuku: 2 } } },
    { id: 'c2b', gate: 2, r: 1, giver: 'nami', town: 'サラム', title: '星読みの 丘', req: 'c2a', steps: [{ t: 'visit', spot: 'dune', night: true, text: '夜に 村の 北東の 砂丘で 星を 読む', fight: ['sunawani', 'hibana', 'sunawani'] }],
      offer: [nm('星占いの ウララ', 'サナちゃんは 毎晩 砂丘で 星を 読んでいたわ。 あの子の 読みは よく 当たった。 ……当たりすぎた。'),
        nm('星占いの ウララ', 'わたし、あの子の 読んだ「星の 落ちる 場所」を、港の 星拾いたちに 売っていたの。 あの子が「星が 泣いてる」って 言うのも 聞かずに。'),
        nm('星占いの ウララ', '遺跡へ 行くと 言った 夜も……止めなかった。 あの 砂丘に 行けば、あの子が 見た ものが わかるかも しれない。')],
      visit: ['星空の 下、砂の 上に 星の 図形が 刻まれている……。 サナの 字だ。「遺跡の 扉は 星の 歌で ひらく」', '……砂の 中から かげものが 飛びだした！'],
      visitDone: ['サナが 残した「星の 歌」を おぼえた！ ウララに 知らせよう。'],
      done: [nm('星占いの ウララ', '星の 歌……！ これで 遺跡の 扉が ひらくはずよ。'), nm('星占いの ウララ', '……あやまる 資格なんて ないけど。 どうか あの子を 連れて 帰って きてね。'),
        who('riku', 'angry', '……あんたの ためじゃ ねえ。'), '遺跡の 扉を ひらく 手がかりを 得た！'], reward: { gold: 600, give: { hoshikake: 1 } } },
    { id: 'c3a', gate: 3, r: 2, giver: 'ryou', town: 'ハヤテ', title: '止まった 風車', when: () => F().c3elder, steps: [{ t: 'collect', item: 'kumowata', n: 3, text: '雲わた 3こ（帆の つくろいに）' }],
      offer: [nm('風車守り カザミ', '……ハル。 地上の 連中と いっしょか。'), who('haru', 'neutral', 'ソヨギさまの 言いつけよ、カザミ。 風の 道を 読ませて。'),
        nm('風車守り カザミ', 'ふん。 風の 道を 知れば、おまえは 下へ 行っちまう。 ……だが 星が 消えるのは 困る。 帆が やぶれて 止まってるんだ。 雲わたを 3つ たのむ。')],
      done: [nm('風車守り カザミ', 'よし、帆が 直った！ あとは てっぺんの 羽根を 回して くれ。')], reward: { gold: 900 } },
    { id: 'c3b', gate: 3, r: 2, giver: 'ryou', town: 'ハヤテ', title: '風車の 羽根', req: 'c3a', steps: [{ t: 'visit', spot: 'mill', text: '風車の 下で 羽根を 回す', fight: ['amatsubame', 'kumomo'] }],
      offer: [nm('風車守り カザミ', '羽根の 軸に かげものが からみついてる。 追いはらって 回して くれ！')], visit: ['風車の 軸に かげものが からみついている！'], visitDone: ['羽根が 回りだした！ 空に 三つの 風の 道が 光った！'],
      done: [nm('風車守り カザミ', '見えるか？ 東・南西・西……あれが 風の 祠への 道だ。'), nm('風車守り カザミ', '……ハル。 下へ 行っても、たまには 風を 送れよ。'), who('haru', 'smile', '……うん。 行こう！ 祠に 風を 通せる。'), '風の 祠に 挑めるように なった！'], reward: { gold: 1200, give: { ganbari: 2 } } },
    { id: 's_sorane', r: 2, giver: 'chibi', town: 'ハヤテ', title: '空の 花', steps: [{ t: 'hunt', region: 2, n: 5, text: '天空の浮島で かげものを 5回 しずめる' }],
      offer: [nm('ハヤテの 子 ソラネ', 'かげものが こわくて、花を つみに 行けないの……。')], done: [nm('ハヤテの 子 ソラネ', 'ありがとう！ これ、お守り！')], reward: { give: { hoshikake: 1, nakayoshi: 2 } } },
    { id: 's_kai', r: 3, giver: 'kai', town: 'アワの里', title: '光る ヒトデ', steps: [{ t: 'seen', sp: 'hitoden', text: '夜の さんご礁で ヒトデンを 見つける（図鑑に 登録）' }],
      offer: [nm('アワの子 カイ', '夜に 光る ヒトデが いるんだって！ 見つけたら 教えて！')], done: [nm('アワの子 カイ', 'ほんとに いたんだ！ はい、しんじゅ！')], reward: { give: { shinju: 2 } } },
  );

  const byId = id => DATA.reqs.find(x => x.id === id);
  const q = id => { const g = G(); g.req = g.req || {}; return g.req[id] = g.req[id] || {}; };
  const done = id => q(id).s === 'd';
  const keyDone = k => G().order > k || DATA.reqs.filter(x => x.key === k).every(x => done(x.id));
  H.load.push(g => { g.req = g.req || {}; });

  // ---- ステップ 判定 ----
  const stepOk = (Q, st, i = st.step || 0) => { const s = Q.steps[i]; if (!s) return true; const g = G();
    if (s.t !== 'collect' && (st.fin || [])[i]) return true;
    if (s.t === 'collect') return (g.inv[s.item] || 0) >= s.n;
    if (s.t === 'shards') return (g.trial[0].shards || 0) >= s.n;
    if (s.t === 'dex') return Object.keys(g.dex.got).length >= s.n;
    if (s.t === 'seen') return !!(g.dex.seen[s.sp] || g.dex.got[s.sp]);
    if (s.t === 'hunt') return (st.c || 0) >= s.n;
    return !!st.v; };
  const stepTxt = (Q, st) => { const s = Q.steps[st.step || 0]; if (!s) return `${Q.town}の ${giverName(Q)}に 報告`; const g = G();
    let prog = s.t === 'collect' ? `（${Math.min(g.inv[s.item] || 0, s.n)}/${s.n}）` : s.t === 'shards' ? `（${g.trial[0].shards || 0}/${s.n}）` : s.t === 'dex' ? `（${Object.keys(g.dex.got).length}/${s.n}）` : s.t === 'hunt' ? `（${st.c || 0}/${s.n}）` : s.t === 'waves' ? `（${st.w || 0}/${s.n}）` : '';
    return s.text + prog; };
  const giverNpc = Q => K.NPCS.find(n => n.id === Q.giver && n.r === Q.r);
  const giverName = Q => { const n = giverNpc(Q); return n ? (n.nm || (DATA.cast[n.id] || {}).name) : ''; };
  const avail = Q => !q(Q.id).s && (!Q.req || done(Q.req)) && (!Q.when || Q.when()) && (Q.key == null || (G().order === Q.key && (Q.key > 0 || G().flags.metGen)));
  // 1ステップ 進める（達成なら 次へ。 全部 おわれば 報告待ち）
  function advance(Q) { const st = q(Q.id); st.step = st.step || 0; st.fin = st.fin || [];
    for (let i = 0; i < Math.min(st.step, Q.steps.length); i++) if (!stepOk(Q, st, i)) { st.step = i; break; }
    while (st.step < Q.steps.length && stepOk(Q, st)) { if (Q.steps[st.step].t !== 'collect') { st.fin[st.step] = 1; st.v = 0; st.w = 0; st.c = 0; } st.step++; } }
  const isReady = Q => { advance(Q); return q(Q.id).step >= Q.steps.length; };

  // ---- 会話（依頼人） ----
  async function talkGiver(n) { const g = G(); const list = DATA.reqs.filter(Q => Q.giver === n.id && Q.r === g.region);
    // 報告
    for (const Q of list) { const st = q(Q.id); if (st.s !== 'a') continue; advance(Q);
      if (isReady(Q)) {
        for (const s of Q.steps) if (s.t === 'collect') g.inv[s.item] -= s.n; st.s = 'd'; const w = Q.reward || {}; const lines = [...Q.done];
        if (w.gold) { g.gold += w.gold; lines.push(`${w.gold}ゴールドを もらった！`); } for (const [k, v] of Object.entries(w.give || {})) { K.gain(k, v); lines.push(`${DATA.items[k].name}を ${v}こ もらった！`); }
        for (const [k, v] of Object.entries(w.blocks || {})) { g.blk[k] = (g.blk[k] || 0) + v; lines.push(`${DATA.blocks[k]}ブロックを ${v}こ もらった！`); }
        Music.jingle('light', K.fieldSong()); await K.say([`【依頼 達成】${Q.title}`, ...lines]); K.save(); K.hud(); return; }
      await K.say([nm(giverName(Q), `たのんだよ。 ${stepTxt(Q, st)}`)]); return; }
    // 依頼
    const Q = list.find(avail); if (Q) { const st = q(Q.id); await K.say([...Q.offer, `【依頼】${Q.title}：${stepTxt(Q, { step: 0 })}`]); st.s = 'a'; st.step = 0; advance(Q); Music.sfx('ok'); K.save(); return; }
    return 'pass'; }
  for (const id of ['nami', 'ryou', 'chibi']) H.talks[id] = async n => { const r = await talkGiver(n); if (r === 'pass') await K.say([nm(n.nm, ({ nami: 'この町を もう一度 灯で いっぱいに したいの。', ryou: '海は きびしいが、正直だ。', chibi: 'リクにいちゃん、つよいんだよ！' })[n.id])]); };
  // 既存 NPC（ゲン・ナギ）は 依頼が あるときだけ 横取り
  for (const id of ['gen', 'nagi', 'ushio', 'kai']) { const prev = H.talks[id]; H.talks[id] = async n => { { const list = DATA.reqs.filter(Q => Q.giver === id && Q.r === G().region); if (list.some(Q => q(Q.id).s === 'a' || avail(Q))) { const r = await talkGiver(n); if (r !== 'pass') return; } } if (id === 'ushio' && G().region === 1) return K.say([nm('村長ハッサン', done('c2a') ? '井戸の 水が うまい。 旅の 方の おかげじゃ。' : 'この 村は 砂漠の 旅人の 休み場所じゃ。')]); return prev ? prev(n) : 'pass'; }; }
  H.talks.inn = (prev => async n => { if (G().region === 0) return K.talkInn(); return prev ? prev(n) : 'pass'; })(H.talks.inn);
  H.talks.item = (prev => async n => { if (G().region === 0) return K.shopUI('item'); return prev ? prev(n) : 'pass'; })(H.talks.item);

  // ---- 訪問・防衛 スポット ----
  const spotOf = s => s.spot === 'desert' ? spots.desert : spots[s.spot];
  H.target.push(cand => { const g = G(); for (const Q of DATA.reqs) { const st = q(Q.id); if (st.s !== 'a' || Q.r !== g.region) continue; const s = Q.steps[st.step || 0]; if (!s || (s.t !== 'visit' && s.t !== 'waves') || st.v) continue; const p = spotOf(s); if (p) cand({ Q }, 'qspot', p.x, p.z, 3.4); } });
  H.labels.qspot = t => { const s = t.o.Q.steps[q(t.o.Q.id).step || 0]; return s.t === 'waves' ? '群れを むかえうつ' : 'しらべる'; };
  H.acts.qspot = async ({ Q }) => { const st = q(Q.id), s = Q.steps[st.step || 0];
    if (s.night && World.skyInfo(G().tod).night < .5) { const c = await K.menu({ title: 'いまは 昼。 夜にしか 見つからない ようだ。', items: [{ label: '夜まで 待つ' }, { label: 'やめておく' }] }); if (c !== 0) return; await K.fade(true); G().tod = .82; await K.wait(300); await K.fade(false); }
    if (s.t === 'waves') { if (!(await K.confirm(`かげものの 群れが せまってくる。（推奨Lv${LV()}） 迎えうつ？`))) return;
      for (let w = st.w || 0; w < s.n; w++) { await K.say([`第${w + 1}波！`]); const lv = Math.max(1, LV() - 3 + w); const pool = ['watapoko', 'iwanoko', 'mizumochi', 'hanapokke', 'tsuchimogu'];
        const res = await K.runBattle(Array.from({ length: 2 + (w > 0 ? 1 : 0) }, () => ({ sp: pool[Math.floor(K.R() * pool.length)], lv })), { noFlee: true }); if (res !== 'win') return K.defeated(); st.w = w + 1; K.save(); }
      st.v = 1; await K.say(['群れを しりぞけた！（依頼人に 報告しよう）']); advance(Q); K.save(); return; }
    if (Q.visit) await K.say(Q.visit);
    if (s.fight) { const lv = G().region === 0 ? Math.max(2, LV() - 2) : K.wildLevel(K.player.x, K.player.z); const res = await K.runBattle(s.fight.map(sp => ({ sp, lv })), { noFlee: true }); if (res !== 'win') return K.defeated(); }
    st.v = 1; if (Q.visitDone) await K.say(Q.visitDone); Music.sfx('friend'); advance(Q); K.save(); };
  H.fx.push((fx, dt, T) => { const g = G(); for (const Q of DATA.reqs) { const st = q(Q.id); if (st.s !== 'a' || Q.r !== g.region) continue; const s = Q.steps[st.step || 0]; if (!s || (s.t !== 'visit' && s.t !== 'waves') || st.v) continue; const p = spotOf(s); if (!p) continue;
    const y = K.hAt(p.x, p.z); fx.push({ type: 1, p: [p.x, y + 1.2 + Math.sin(T * 2) * .2, p.z], size: [2.2, 2.2], grow: 1.3, tint: s.t === 'waves' ? [1, .45, .35] : [.6, .9, 1] }); } });
  // ---- 討伐 カウント ----
  H.battleEnd.push(async (res, specs) => { if (res !== 'win' || specs.some(s => s.boss)) return; for (const Q of DATA.reqs) { const st = q(Q.id); if (st.s !== 'a') continue; const s = Q.steps[st.step || 0]; if (s && s.t === 'hunt' && G().region === s.region) st.c = (st.c || 0) + 1; } });

  // ---- 灯台の 門番（鍵が ないと ひらかない）と 目的 ----
  DATA.trials.forEach((T, i) => { T.text = '灯台の 奥で、闇に のまれた 番人が 灯を ふさいでいる。'; T.name = ['野原の灯台', '双塔の灯台', '岩山の灯台', '月夜の灯台', '崖の灯台'][i] || T.name; });
  // 第1灯台：欠片が 3つ そろっていれば ゲンへ 報告に もどらず、扉で そのまま 鍵に なる
  const autoKey0 = () => { const Q = DATA.reqs.find(x => x.key === 0); if (!Q || done(Q.id) || G().order !== 0 || (G().trial[0].shards || 0) < 3) return false; const st = q(Q.id); st.s = 'd'; st.step = Q.steps.length; G().gold += (Q.reward || {}).gold || 0; Music.sfx('friend'); K.toast(`灯の欠片を 扉に はめこんだ！ 扉が ひらいた<br><span style="font-size:.6em">【依頼 達成】${Q.title}（+${(Q.reward || {}).gold || 0}G）</span>`, 2600); K.save(); K.hud(); return true; };
  H.beaconGate = b => { const k = G().order; if (keyDone(k)) return null; if (k === 0 && b && b.i === 0 && autoKey0()) return null; const Q = DATA.reqs.find(x => x.key === k && !done(x.id));
    return ['灯台の 扉は かたく 閉ざされている……。', Q ? `（${Q.town}の ${giverName(Q)}が 鍵の ことを 知っているようだ）` : '（まだ 鍵が ない）']; };
  H.beaconObj = () => { const k = G().order; if (keyDone(k)) return null; const Q = DATA.reqs.find(x => x.key === k && !done(x.id)); if (!Q) return null; const st = q(Q.id); const lv = DATA.guardLv[k];
    if (!st.s) { const n = giverNpc(Q); return { t: `【灯台 ${k}/5・推奨Lv${lv}】${Q.town}の ${giverName(Q)}に 話を 聞こう`, p: n ? { x: n.x, z: n.z } : null }; }
    const fin = isReady(Q); const s = Q.steps[st.step || 0];
    if (fin && k === 0) return { t: `【灯台 0/5・推奨Lv${lv}】灯台の 扉に 欠片を はめこもう`, p: R0.beacons[0] };
    if (fin) { const n = giverNpc(Q); return { t: `【灯台 ${k}/5】${Q.town}の ${giverName(Q)}に 報告しよう`, p: n ? { x: n.x, z: n.z } : null }; }
    const p = s && (s.t === 'visit' || s.t === 'waves') ? spotOf(s) : s && s.t === 'shards' ? (() => { const b0 = R0.beacons[0]; const got = G().trial[0].got || []; const sh = b0.shards.find((_, i) => !got.includes(i)); return sh; })() : null;
    return { t: `【灯台 ${k}/5・${Q.title}】${stepTxt(Q, st)}`, p }; };
  const gateDone = n => DATA.reqs.filter(x => x.gate === n).every(x => done(x.id));
  H.gate2 = () => (F().c2mid || gateDone(2)) ? null : ['遺跡の 奥の 扉は 星の 紋様で 閉ざされている……。', '（東の 砂漠の オアシスの村「サラム」で 手がかりを さがそう）'];
  H.gate3 = () => (G().wind.some(Boolean) || gateDone(3)) ? null : ['祠の 風は よどんでいて、道が 見えない……。', '（西の 小島「ハヤテ」の 風車守りが 風の 道を 読めるらしい。 上昇気流で わたろう）'];
  const gateObj = (n, lead) => { const Q = DATA.reqs.find(x => x.gate === n && !done(x.id)); if (!Q) return null; const st = q(Q.id);
    if (!st.s) { const nn = giverNpc(Q); return { t: `${lead}${Q.town}の ${giverName(Q)}に 会おう`, p: nn ? { x: nn.x, z: nn.z } : null }; }
    const ready = isReady(Q); const s = Q.steps[st.step || 0];
    if (ready) { const nn = giverNpc(Q); return { t: `${lead}${Q.town}の ${giverName(Q)}に 報告`, p: nn ? { x: nn.x, z: nn.z } : null }; }
    return { t: `${lead}${Q.title}：${stepTxt(Q, st)}`, p: s && (s.t === 'visit' || s.t === 'waves') ? spotOf(s) : null }; };
  H.obj2 = () => (F().c2mid || gateDone(2)) ? null : gateObj(2, '【第2章】');
  H.obj3 = () => (G().wind.some(Boolean) || gateDone(3)) ? null : gateObj(3, '【第3章】');
  H.mapMarks.push((r, pos) => r === 1 ? [`<span class="mk town" style="${pos(oasis.x, oasis.z)}">サラム</span>`] : r === 2 ? [`<span class="mk town" style="${pos(hayate.x, hayate.z)}">ハヤテ</span>`] : []);
  H.warps.push(r => r === 1 && done('c2a') ? [{ n: 'サラム', x: oasis.x + 1.5, z: oasis.z + 8 }] : r === 2 && done('c3a') ? [{ n: 'ハヤテ', x: hayate.x, z: hayate.z + 6 }] : []);
  K.reqList = () => DATA.reqs.filter(Q => q(Q.id).s === 'a').map(Q => { const st = q(Q.id); const ready = isReady(Q); const s = Q.steps[st.step || 0]; const n = giverNpc(Q); const p = ready ? (n ? { x: n.x, z: n.z } : null) : s && (s.t === 'visit' || s.t === 'waves') ? spotOf(s) : null;
    return { id: 'r' + Q.id, n: `${Q.key != null ? '【鍵】' : '【依頼】'}${Q.title}（${Q.town}）`, d: ready ? `${giverName(Q)}に 報告しよう` : stepTxt(Q, st), p, r: Q.r }; });
  // ---- 地図・ワープ・地名 ----
  H.mapMarks.push((r, pos) => { const out = []; if (r === 0) out.push(`<span class="mk town" style="${pos(SX, SZ)}">シオミ</span>`);
    for (const Q of DATA.reqs) { if (Q.r !== r) continue; const st = q(Q.id); const n = giverNpc(Q); if (n && (avail(Q) || st.s === 'a')) out.push(`<span class="mk" style="${pos(n.x, n.z)};color:#ffd24a" title="${Q.title}">${st.s === 'a' ? '？' : '！'}</span>`); } return out; });
  H.warps.push(r => r === 0 && (G().warp || G().order >= 2) ? [{ n: 'シオミ', x: SX + 1.5, z: SZ + 5 }] : []);
  (K.extraAreas = K.extraAreas || []).push({ rg: 0, id: 'shiomi', x: SX, z: SZ, r: 26, n: '潮見の町 シオミ', s: '風灯の島' });
  // 頭上の「！」（依頼あり）
  H.fx.push((fx, dt, T) => { const g = G(); for (const Q of DATA.reqs) { if (Q.r !== g.region || !avail(Q)) continue; const n = giverNpc(Q); if (!n || (n.show && !n.show())) continue; if (Math.hypot(n.x - K.player.x, n.z - K.player.z) > 60) continue;
    fx.push({ type: 1, p: [n.x, K.surfaceAt(n.x, n.z, 99) + 2.6 + Math.sin(T * 3) * .1, n.z], size: [.9, .9], grow: 1.2, tint: [1, .85, .2] }); } });
})();
