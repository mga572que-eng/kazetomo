import assert from 'node:assert/strict';
import fs from 'node:fs';
import vm from 'node:vm';
const maps=Array.from({length:4},()=>new Map());let region=2;
const cell=(x,y,z)=>`${x},${y},${z}`;
const B={set:(x,y,z,t,p,r=region)=>maps[r].set(cell(x,y,z),{t,p}),rm:(x,y,z,r=region)=>maps[r].delete(cell(x,y,z)),get:(x,y,z)=>maps[region].get(cell(x,y,z))?.t,has:(x,y,z)=>maps[region].has(cell(x,y,z)),isProt:(x,y,z)=>!!maps[region].get(cell(x,y,z))?.p,move(x,y,z,X,Y,Z,r=region){const m=maps[r],c=m.get(cell(x,y,z));if(!c)return false;m.delete(cell(x,y,z));m.set(cell(X,Y,Z),c);return true;}};
const H={frame:[],fx:[],target:[],push:[],load:[],mapMarks:[],menu:[],labels:{},acts:{}};
const K={HOOK:H,G:{region:0,lh:[0,0,0],lhDun:{0:1},gold:100,inv:{}},REG:[{beacons:Array.from({length:5},(_,i)=>({x:i*10,z:0,lit:false}))},{},{},{lh:Array.from({length:3},(_,i)=>({x:i*10,z:10}))}],player:{x:0,z:0,y:1},cam:{},trail:[],phase:'field',enemies:[],toast(){},fade:async()=>{},wait:async()=>{},say:async()=>{},confirm:async()=>false,menu:async()=>1,gain(k,n){this.G.inv[k]=(this.G.inv[k]||0)+n;},save(){},hud(){},fieldSong(){},surfaceAt:()=>1,warpTo:async(x,z)=>Object.assign(K.player,{x,z,y:1})};
const context=vm.createContext({window:{KZ:K},World:{Blocks:B,setRegion:r=>region=r,get region(){return region;}},Music:{sfx(){},jingle(){}},DATA:{items:{shizuku:{name:'しずく'},pan:{name:'パン'}}}});
vm.runInContext(fs.readFileSync(new URL('../lighthouses.js',import.meta.url),'utf8'),context);
assert.equal(region,2,'initial construction must restore the current World region');
assert.equal(K.lhDuns.length,8);assert.equal(new Set(K.lhDuns.map(K.lhDungeon.key)).size,8);
assert.equal(K.G.lhDun[0],1,'existing clear record preserved');
const sea=K.lhDuns.find(d=>d.r===3&&d.i===1);K.G.region=3;region=3;
await K.lhDungeon.enter(sea);assert.equal(K.lhDungeon.here(),null,'unlit sea lighthouse cannot be entered');
K.G.lh[1]=1;await K.lhDungeon.enter(sea);assert.equal(K.lhDungeon.here(),sea);
assert.equal(K.G.lhDunExit.i,1);assert.equal(K.G.lhDunExit.r,3);
const key=K.lhDungeon.key(sea),gold=K.G.gold;
// Landing beyond a door must not award completion or silently open the second door.
Object.assign(K.player,{x:sea.x+.5,z:sea.z-42,y:sea.y+5});H.frame.forEach(f=>f(.016,1));
await H.acts.lhdGoal(sea);assert.equal(K.G.gold,gold);assert.equal(K.G.lhDun[key],undefined);assert.ok(!K.lhSt[key].o2);
// Retry from an advanced room must return to the entrance instead of trapping the player.
await H.acts.lhdOut(sea);assert.equal(K.player.z,sea.gate.z-1);assert.ok(!K.lhSt[key].o1);
Object.assign(K.player,{x:sea.x+.5,z:sea.z-11,y:sea.y+1});H.frame.forEach(f=>f(.016,2));
await H.acts.lhdControl({d:sea,j:(sea.sequence[0]+1)%3});assert.equal(K.lhSt[key].sequence,0);
for(const j of sea.sequence)await H.acts.lhdControl({d:sea,j});assert.equal(K.lhSt[key].o2,1);
for(const [a,b,h]of sea.parts.shards){Object.assign(K.player,{x:sea.x+a+.5,z:sea.z+b+.5,y:sea.y+h});H.frame.forEach(f=>f(.016,3));}
await H.acts.lhdGoal(sea);assert.equal(K.G.gold,gold+sea.reward.gold);assert.equal(K.G.lhDun[0],1);
await H.acts.lhdGoal(sea);assert.equal(K.G.gold,gold+sea.reward.gold,'reward only once');
H.load.forEach(f=>f(K.G));H.frame.forEach(f=>f(.016,4));const entrance=K.lhDungeon.source(sea);assert.equal(K.player.x,entrance.x+3);assert.equal(K.player.z,entrance.z+3);
console.log('PASS: lighthouse entry, old save record, unique sea key, skip prevention, retry, puzzle order, reward once, load rescue, region restoration');
// Cosmetic regeneration must preserve doors, IDs, NPC anchors and player blocks.
const townKeys=['kazami','shiomi','minato','oasis','kukuru','hayate','awa','royal','lucky','brave'];
const homes=townKeys.map((id,i)=>({id:'home_'+id,x:i*20,z:0,npc:{x:i*20+.5,z:4.1},yaw:0}));
region=0;
for(const h of homes){for(let k=0;k<3;k++)for(let x=-2;x<=2;x++)for(let z=-2;z<=2;z++){if(Math.abs(x)!==2&&Math.abs(z)!==2)continue;if(x===0&&z===2&&k<2)continue;B.set(h.x+x,1+k,z,4,true,0);}for(let k=0;k<4;k++){const edge=3-k;for(let x=-edge;x<=edge;x++)for(let z=-edge;z<=edge;z++){if(k<3&&Math.abs(x)<edge&&Math.abs(z)<edge)continue;B.set(h.x+x,4+k,z,3,true,0);}}}
B.set(0,4,0,11,false,0);const anchors=JSON.stringify(homes);
const townK={REG:[{houses:homes},{houses:[]},{houses:[]},{houses:[]}],extraHouses:[],hAt:()=>0,townLife:{TOWNS:townKeys.map((key,i)=>({key,r:0,at:()=>({x:i*20,z:0})}))}};
region=2;context.window.KZ=townK;vm.runInContext(fs.readFileSync(new URL('../townbuildings.js',import.meta.url),'utf8'),context);
assert.equal(JSON.stringify(homes),anchors);assert.equal(region,2);assert.equal(townK.townBuildings.buildings.length,10);
region=0;assert.equal(B.get(0,4,0),11);assert.equal(B.isProt(0,4,0),false);
for(const h of homes){assert.equal(B.has(h.x,1,2),false);assert.equal(B.has(h.x,2,2),false);}
console.log('PASS: all town profiles, entrance gaps, NPC/ID invariance, player block preservation, region restoration');
